﻿using Cafe_Managment.Model;
using Cafe_Managment.Repositories;
using Cafe_Managment.Utilities;
using Cafe_Managment.View.DialogWindows.RegisterForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Cafe_Managment.ViewModel.DialogWindowsVM
{
    public class RegistrationVM : ViewModelBase
    {
        UserRepository userRepository;
        DateTime _dateOfBirth;
        private bool _isViewVisible = true;
        private object _activePage;
        private EmpData _newEmp = new EmpData();
        private object FirstPage = new RegisterFirst();
        private object SecondPage = new RegisterSecond();
        private string _loginerrorMessage;
        private string _birtherrorMessage;



        public List<string> RoleTable { get; set; }
        public List<string> BranchTable { get; set; }

        public DateTime DateOfBirth
        {
            get { return _dateOfBirth; }
            set { _dateOfBirth = value;
                OnPropertyChanged(nameof(DateOfBirth));
            }
        }
        public string LoginErrorMessage
        {
            get { return _loginerrorMessage; }
            set { _loginerrorMessage = value; OnPropertyChanged(nameof(LoginErrorMessage)); }
        }
        public string BirthErrorMessage
        {
            get { return _birtherrorMessage; }
            set { _birtherrorMessage = value; OnPropertyChanged(nameof(BirthErrorMessage)); }
        }

        public bool IsViewVisible
        {
            get { return _isViewVisible; }
            set { _isViewVisible = value; OnPropertyChanged(); }
        }

        public object ActivePage
        {
            get => _activePage;
            set
            {
                _activePage = value;
                OnPropertyChanged();
            }
        }
        public EmpData NewEmp
        {
            get { return _newEmp; }
            set
            {
                _newEmp.Name = value.Name;
                _newEmp.Surname = value.Surname;
                _newEmp.Patronomic = value.Patronomic;
                _newEmp.BirthDay = value.BirthDay;
                _newEmp.Login = value.Login;
                _newEmp.Password = value.Password;
                _newEmp.Role = value.Role;
                _newEmp.Branch = value.Branch;
                OnPropertyChanged(nameof(NewEmp));
            }
        }

        public ICommand CloseWindowCommand { get; set; }
        public ICommand RegisterCommand { get; set; }
        public ICommand NextPageCommand { get; }
        public ICommand PreviousPageCommand { get; }

        public RegistrationVM() 
        {
            DateOfBirth = DateTime.Now;
            userRepository = new UserRepository();
            RoleTable = userRepository.GetRoles();
            RoleTable.Add("Выберите роль");
            BranchTable = userRepository.GetBranches();
            BranchTable.Add("Выберите филиал");
            LoginErrorMessage = "";
            BirthErrorMessage = "";

            NewEmp = new EmpData
            {
                Name = "",
                Surname = "",
                Patronomic = "",
                BirthDay = "",
                Login = "",
                Password = "",
                Role = RoleTable.Count()-1,
                Branch = BranchTable.Count()-1,
            };

            ActivePage = new RegisterFirst();

            CloseWindowCommand = new RelayCommand(ExecuteCloseWindowCommand);
            NextPageCommand = new RelayCommand(ExecuteNextPageCommand, CanExecuteNextCommand);
            PreviousPageCommand = new RelayCommand(ExecutePreviousPageCommand);
            RegisterCommand = new RelayCommand(ExecuteRegisterCommand, CanExecuteRegisterCommand);
           
        }

        
        private void ExecuteRegisterCommand(object obj)
        {
            LoginErrorMessage = "";
            
            if (userRepository.IfUserExists(NewEmp.Login))
            {
                LoginErrorMessage = "Данный пользователь уже существует";
            }
            else
            {
                userRepository.Add(NewEmp);
                MessageBox.Show($"Новый пользователь с логином {NewEmp.Login} был добавлен!");
                IsViewVisible = false;
            }
        }
        private bool CanExecuteRegisterCommand(object arg)
        {

            return _newEmp.Login.Length > 0 
                && _newEmp.Password.Length > 0 
                && _newEmp.Role != RoleTable.Count-1
                && _newEmp.Branch != BranchTable.Count - 1;

        }

        private void ExecutePreviousPageCommand(object obj)
        {
            ActivePage = FirstPage;

        }
        private void ExecuteNextPageCommand(object obj)
        {
            if (IsMoreSixteen())
            {
                NewEmp.BirthDay = DateOfBirth.ToString("yyyy-MM-dd");
                ActivePage = SecondPage;
                BirthErrorMessage = "";
            }
            else
            {
                MessageBox.Show("Иди проспись");
            }
        }

        private bool IsMoreSixteen()
        {
            int age = DateTime.Today.Year - DateOfBirth.Year;
            if (DateOfBirth > DateTime.Today.AddYears(-age))
                age--;
            return age >= 16;
        }

        private bool CanExecuteNextCommand(object arg)
        {
            return _newEmp.Name.Length > 0 && _newEmp.Surname.Length > 0 
                && _newEmp.Patronomic.Length > 0 && DateOfBirth!=null;
        }


        private void ExecuteCloseWindowCommand(object obj)
        {
            IsViewVisible = false;
        }


    }
}
